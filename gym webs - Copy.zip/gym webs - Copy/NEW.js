//all feilds 
let firstName=document.querySelector("#firstName");
let lastName=document.querySelector("#lastName");
let password=document.querySelector("#password");
let confirmPassword=document.querySelector("#confirmPasword");
let email=document.querySelector("#email");
let phone=document.querySelector("#phone");

//span for some error messages
let help=document.querySelector(".helper");
//span for common Errors
let commonErrors=document.querySelector("#commonErrors");
//form 
let form=document.querySelector("#signUpForm");

form.addEventListener("submit",event=>{
    event.preventDefault();
    
    //if all feilds Not Empty
    if(checkFeildsEmpty(firstName)&& checkFeildsEmpty(lastName) && checkFeildsEmpty(password)
    && checkFeildsEmpty(confirmPassword) && checkFeildsEmpty(email) && checkFeildsEmpty(phone)){
    
    // if password length less than 6 charagters the submition not hapen 
    if(!checkPasswordLength()){
    return;
    }
    
    // if all is okay 
    commonErrors.textContent="Succesfully Regsitered Thank You!";
    commonErrors.style.background ="#74d3b3";
    commonErrors.style.color="#fff";
    // reset all feilds of the form
    form.reset();
    }else{
    // calling the checkFeildsEmpty function to check if there any Empty Input
    checkFeildsEmpty(firstName);
    checkFeildsEmpty(lastName);
    checkFeildsEmpty(password);
    checkFeildsEmpty(confirmPassword);
    checkFeildsEmpty(email);
    checkFeildsEmpty(phone);
    
    }
    });
    
    //function checking for Password Length
function checkPasswordLength(){
    if(password.value.length<6){
    commonErrors.textContent="Password Must greater than 6 Characters";
    password.style.border='1px solid red';
    commonErrors.style.color="red";
    return false;
    }else{
    password.style.border='1px solid rgba(0,0,0,.125)';
    commonErrors.style.color="#000";
    commonErrors.textContent='';
    return true;
    }
    
    }
 
    function checkConfirmPassword(){
        if(confirmPassword.value!=password.value){
        commonErrors.textContent="Password Must be Same";
        confirmPassword.style.border='1px solid red';
        commonErrors.style.color="red";
        return false;
        }else{
        confirmPassword.style.border='1px solid rgba(0,0,0,.125)';
        //commonErrors.style.color = "#000";
        commonErrors.textContent='';
        return true;
        }
        }
        confirmPassword.value=''
       
    setTimeout(()=>{
        calculateMessage.textContent=''
    }, 4000)
    

        // checkFeildsEmpty fuunction to check if there any Empty Feilds
function checkFeildsEmpty(feild){
    if(feild.value===''||feild.value ==null){
    feild.style.border='1px solid red';
    commonErrors.textContent="All Fiels Must Not Empty";
    commonErrors.style.color="red";
    return false;
    }else{
    feild.style.border='1px solid rgba(0,0,0,.125)';
    return true;
    }
    }
    
    
         
    
    
    


